var H=Object.defineProperty;var O=(d,e,r)=>e in d?H(d,e,{enumerable:!0,configurable:!0,writable:!0,value:r}):d[e]=r;var N=(d,e,r)=>O(d,typeof e!="symbol"?e+"":e,r);import{j as t}from"./ui-vendor-DlZIaINd.js";import{r as b}from"./react-vendor-CbTYwD9p.js";import{C as x,a as f,b as y,c as u}from"./card-n4uODT2g.js";import{B as v}from"./button-CWghX4lQ.js";import{A,a as z,b as F}from"./avatar-C9UegU7R.js";import{B as S}from"./badge-dX-nOAIg.js";import{S as $}from"./separator-Di4inxfb.js";import{E as D}from"./external-link-C4bbU-J3.js";import{s as j,a as w}from"./index-D9eMyG03.js";import{l as C}from"./export-features-jL3O0GuP.js";import{a as M}from"./router-vendor-BssJdvT9.js";import{L as T}from"./loader-circle-e-tYDlnG.js";import{C as B}from"./circle-alert-B29IBu6A.js";import{S as V}from"./share-2-DzMM8Ikq.js";import"./supabase-vendor-CYMOQS5a.js";import"./query-vendor-CGp1cCDs.js";function I({sharedContent:d}){var s,i;const{content:e,owner:r}=d;return t.jsxs("div",{className:"max-w-4xl mx-auto p-6 space-y-6",children:[t.jsx(x,{children:t.jsxs(f,{children:[t.jsxs("div",{className:"flex items-center gap-4",children:[t.jsxs(A,{className:"h-12 w-12",children:[t.jsx(z,{src:r.avatarUrl,alt:r.displayName}),t.jsx(F,{children:((s=r.displayName)==null?void 0:s.charAt(0))||((i=r.handle)==null?void 0:i.charAt(0))||"U"})]}),t.jsxs("div",{children:[t.jsx("h1",{className:"text-2xl font-bold",children:e.title}),t.jsxs("p",{className:"text-muted-foreground",children:["Shared by ",r.displayName||r.handle||"Anonymous"]})]})]}),e.tagline&&t.jsx("p",{className:"text-lg text-muted-foreground italic mt-2",children:e.tagline})]})}),e.voiceTone.length>0&&t.jsxs(x,{children:[t.jsx(f,{children:t.jsx(y,{children:"Voice & Tone"})}),t.jsx(u,{children:t.jsx("div",{className:"flex flex-wrap gap-2",children:e.voiceTone.map((a,n)=>t.jsx(S,{variant:"secondary",children:a},n))})})]}),e.signaturePhrases.length>0&&t.jsxs(x,{children:[t.jsx(f,{children:t.jsx(y,{children:"Signature Phrases"})}),t.jsx(u,{children:t.jsx("div",{className:"space-y-2",children:e.signaturePhrases.map((a,n)=>t.jsxs("blockquote",{className:"border-l-4 border-primary pl-4 italic",children:['"',a,'"']},n))})})]}),t.jsxs("div",{className:"grid md:grid-cols-2 gap-6",children:[e.strengths.length>0&&t.jsxs(x,{children:[t.jsx(f,{children:t.jsx(y,{children:"Strengths"})}),t.jsx(u,{children:t.jsx("ul",{className:"space-y-2",children:e.strengths.map((a,n)=>t.jsxs("li",{className:"flex items-start gap-2",children:[t.jsx("span",{className:"text-green-500 mt-1",children:"✓"}),t.jsx("span",{children:a})]},n))})})]}),e.weaknesses.length>0&&t.jsxs(x,{children:[t.jsx(f,{children:t.jsx(y,{children:"Areas for Growth"})}),t.jsx(u,{children:t.jsx("ul",{className:"space-y-2",children:e.weaknesses.map((a,n)=>t.jsxs("li",{className:"flex items-start gap-2",children:[t.jsx("span",{className:"text-orange-500 mt-1",children:"→"}),t.jsx("span",{children:a})]},n))})})]})]}),e.palette.length>0&&t.jsxs(x,{children:[t.jsx(f,{children:t.jsx(y,{children:"Color Palette"})}),t.jsx(u,{children:t.jsx("div",{className:"grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4",children:e.palette.map((a,n)=>t.jsxs("div",{className:"text-center",children:[t.jsx("div",{className:"w-full h-16 rounded-lg border shadow-sm mb-2",style:{backgroundColor:a.hex}}),t.jsx("p",{className:"text-sm font-medium",children:a.name}),t.jsx("p",{className:"text-xs text-muted-foreground",children:a.hex})]},n))})})]}),t.jsxs(x,{children:[t.jsx(f,{children:t.jsx(y,{children:"Typography"})}),t.jsx(u,{children:t.jsxs("div",{className:"grid md:grid-cols-2 gap-6",children:[t.jsxs("div",{children:[t.jsx("h3",{className:"font-semibold mb-2",children:"Heading Font"}),t.jsxs("div",{className:"p-4 border rounded-lg",style:{fontFamily:e.fonts.heading},children:[t.jsx("p",{className:"text-2xl font-bold",children:e.fonts.heading}),t.jsx("p",{className:"text-sm text-muted-foreground",children:"The quick brown fox jumps over the lazy dog"})]})]}),t.jsxs("div",{children:[t.jsx("h3",{className:"font-semibold mb-2",children:"Body Font"}),t.jsxs("div",{className:"p-4 border rounded-lg",style:{fontFamily:e.fonts.body},children:[t.jsx("p",{className:"text-lg",children:e.fonts.body}),t.jsx("p",{className:"text-sm text-muted-foreground",children:"The quick brown fox jumps over the lazy dog"})]})]})]})})]}),e.bio&&t.jsxs(x,{children:[t.jsx(f,{children:t.jsx(y,{children:"Bio"})}),t.jsx(u,{children:t.jsx("p",{className:"leading-relaxed",children:e.bio})})]}),e.examples&&e.examples.length>0&&t.jsxs(x,{children:[t.jsx(f,{children:t.jsx(y,{children:"Usage Examples"})}),t.jsx(u,{children:t.jsx("div",{className:"space-y-4",children:e.examples.map((a,n)=>t.jsxs("div",{className:"border-l-4 border-primary pl-4",children:[t.jsx("h4",{className:"font-semibold text-sm text-muted-foreground mb-1",children:a.context}),t.jsxs("blockquote",{className:"italic",children:['"',a.text,'"']})]},n))})})]}),t.jsxs("div",{className:"text-center py-6",children:[t.jsx($,{className:"mb-4"}),t.jsxs("p",{className:"text-sm text-muted-foreground",children:["Shared on ",d.createdAt.toLocaleDateString(),d.expiresAt&&t.jsxs("span",{children:[" • Expires ",d.expiresAt.toLocaleDateString()]})]})]})]})}function q({sharedContent:d}){var s,i;const{content:e,owner:r}=d;return t.jsxs("div",{className:"max-w-4xl mx-auto p-6 space-y-6",children:[t.jsx(x,{children:t.jsx(f,{children:t.jsxs("div",{className:"flex items-center gap-4",children:[t.jsxs(A,{className:"h-12 w-12",children:[t.jsx(z,{src:r.avatarUrl,alt:r.displayName}),t.jsx(F,{children:((s=r.displayName)==null?void 0:s.charAt(0))||((i=r.handle)==null?void 0:i.charAt(0))||"U"})]}),t.jsxs("div",{children:[t.jsx("h1",{className:"text-3xl font-bold",children:e.name}),t.jsx("h2",{className:"text-xl text-muted-foreground",children:e.role}),t.jsxs("p",{className:"text-sm text-muted-foreground",children:["Shared by ",r.displayName||r.handle||"Anonymous"]})]})]})})}),e.summary&&t.jsxs(x,{children:[t.jsx(f,{children:t.jsx(y,{children:"Summary"})}),t.jsx(u,{children:t.jsx("p",{className:"leading-relaxed text-lg",children:e.summary})})]}),e.experience.length>0&&t.jsxs(x,{children:[t.jsx(f,{children:t.jsx(y,{children:"Experience"})}),t.jsx(u,{children:t.jsx("div",{className:"space-y-6",children:e.experience.map((a,n)=>t.jsxs("div",{className:"relative",children:[n>0&&t.jsx($,{className:"mb-6"}),t.jsxs("div",{className:"space-y-2",children:[t.jsxs("div",{className:"flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2",children:[t.jsx("h3",{className:"text-xl font-semibold",children:a.role}),t.jsx(S,{variant:"outline",className:"w-fit",children:a.dates})]}),t.jsx("p",{className:"text-lg text-muted-foreground font-medium",children:a.org}),t.jsx("ul",{className:"space-y-2 mt-4",children:a.bullets.map((o,l)=>t.jsxs("li",{className:"flex items-start gap-3",children:[t.jsx("span",{className:"text-primary mt-2 text-xs",children:"●"}),t.jsx("span",{className:"leading-relaxed",children:o})]},l))})]})]},n))})})]}),e.skills.length>0&&t.jsxs(x,{children:[t.jsx(f,{children:t.jsx(y,{children:"Skills"})}),t.jsx(u,{children:t.jsx("div",{className:"flex flex-wrap gap-2",children:e.skills.map((a,n)=>t.jsx(S,{variant:"secondary",className:"text-sm",children:a},n))})})]}),e.links.length>0&&t.jsxs(x,{children:[t.jsx(f,{children:t.jsx(y,{children:"Links"})}),t.jsx(u,{children:t.jsx("div",{className:"grid sm:grid-cols-2 gap-4",children:e.links.map((a,n)=>t.jsxs("a",{href:a.url,target:"_blank",rel:"noopener noreferrer",className:"flex items-center gap-2 p-3 border rounded-lg hover:bg-muted/50 transition-colors",children:[t.jsx(D,{className:"h-4 w-4 text-muted-foreground"}),t.jsxs("div",{className:"flex-1 min-w-0",children:[t.jsx("p",{className:"font-medium truncate",children:a.label}),t.jsx("p",{className:"text-sm text-muted-foreground truncate",children:a.url})]})]},n))})})]}),t.jsxs("div",{className:"text-center py-6",children:[t.jsx($,{className:"mb-4"}),t.jsxs("p",{className:"text-sm text-muted-foreground",children:["Shared on ",d.createdAt.toLocaleDateString(),d.expiresAt&&t.jsxs("span",{children:[" • Expires ",d.expiresAt.toLocaleDateString()]})]})]})]})}class E{static async shareBrandRider(e,r={}){return this.createShare("brand",e,r)}static async shareCV(e,r={}){return this.createShare("cv",e,r)}static async getSharedContent(e){try{const{data:r,error:s}=await j.rpc("get_share_by_token",{_token:e});if(s||!r||r.length===0)return null;const i=r[0];let a,n;if(i.kind==="brand"){const{data:o,error:l}=await j.from("brands").select(`
            *,
            profiles!inner(display_name, handle, avatar_url)
          `).eq("id",i.target_id).single();if(l||!o)throw new Error("Brand not found");a=this.mapBrandToBrandRider(o),n=o.profiles}else{const{data:o,error:l}=await j.from("cvs").select(`
            *,
            profiles!inner(display_name, handle, avatar_url)
          `).eq("id",i.target_id).single();if(l||!o)throw new Error("CV not found");a=this.mapCVToCV(o),n=o.profiles}return{id:i.id,kind:i.kind,content:a,owner:{displayName:n.display_name,handle:n.handle,avatarUrl:n.avatar_url},createdAt:new Date(i.created_at),expiresAt:i.expires_at?new Date(i.expires_at):void 0}}catch(r){return console.error("Error fetching shared content:",r),null}}static async getUserShares(){try{const{data:e}=await j.auth.getUser();if(!e.user)throw new Error("User not authenticated");const{data:r,error:s}=await j.from("shares").select("*").eq("user_id",e.user.id).order("created_at",{ascending:!1});if(s)throw s;return await Promise.all(r.map(async a=>{let n="Untitled";try{if(a.kind==="brand"){const{data:o}=await j.from("brands").select("title").eq("id",a.target_id).single();n=(o==null?void 0:o.title)||"Untitled Brand"}else if(a.kind==="cv"){const{data:o}=await j.from("cvs").select("title").eq("id",a.target_id).single();n=(o==null?void 0:o.title)||"Untitled CV"}}catch{console.warn("Failed to fetch title for share:",a.id)}return{id:a.id,kind:a.kind,targetId:a.target_id,token:a.token,url:this.generateShareURL(a.token),createdAt:new Date(a.created_at),expiresAt:a.expires_at?new Date(a.expires_at):void 0,title:n}}))}catch(e){throw console.error("Error fetching user shares:",e),e}}static async deleteShare(e){try{const{error:r}=await j.from("shares").delete().eq("id",e);if(r)throw r}catch(r){throw console.error("Error deleting share:",r),r}}static async updateShareExpiration(e,r){try{const{error:s}=await j.from("shares").update({expires_at:r==null?void 0:r.toISOString()}).eq("id",e);if(s)throw s}catch(s){throw console.error("Error updating share expiration:",s),s}}static isShareValid(e){return e.expiresAt?e.expiresAt>new Date:!0}static generateToken(){const e=new Uint8Array(32);return crypto.getRandomValues(e),Array.from(e,r=>r.toString(16).padStart(2,"0")).join("")}static async createShare(e,r,s){var i;try{const{data:a}=await j.auth.getUser();if(!a.user)throw new Error("User not authenticated");const n=this.generateToken(),{data:o,error:l}=await j.from("shares").insert({user_id:a.user.id,kind:e,target_id:r,token:n,expires_at:(i=s.expiresAt)==null?void 0:i.toISOString()}).select().single();if(l)throw l;return{id:o.id,token:o.token,url:this.generateShareURL(o.token),expiresAt:o.expires_at?new Date(o.expires_at):void 0}}catch(a){throw console.error("Error creating share:",a),a}}static generateShareURL(e){return`${this.BASE_URL}/share/${e}`}static mapBrandToBrandRider(e){return{title:e.title||"Untitled Brand",tagline:e.tagline||"",voiceTone:e.tone_notes?[e.tone_notes]:[],signaturePhrases:e.signature_phrases||[],strengths:e.strengths||[],weaknesses:e.weaknesses||[],palette:e.color_palette||[],fonts:e.fonts||{heading:"Arial",body:"Arial"},bio:e.bio||"",examples:e.examples||[],format:e.format_preset||"professional"}}static mapCVToCV(e){return{name:e.title||"Untitled CV",role:"Professional",summary:e.summary||"",experience:e.experience||[],skills:e.skills||[],links:e.links||[],format:e.format_preset||"professional"}}static getExpirationPresets(){const e=new Date;return[{label:"Never",value:null,description:"Link never expires"},{label:"1 Hour",value:new Date(e.getTime()+60*60*1e3),description:"Expires in 1 hour"},{label:"1 Day",value:new Date(e.getTime()+24*60*60*1e3),description:"Expires in 24 hours"},{label:"1 Week",value:new Date(e.getTime()+7*24*60*60*1e3),description:"Expires in 1 week"},{label:"1 Month",value:new Date(e.getTime()+30*24*60*60*1e3),description:"Expires in 1 month"},{label:"3 Months",value:new Date(e.getTime()+90*24*60*60*1e3),description:"Expires in 3 months"}]}}N(E,"BASE_URL",window.location.origin);class L{static async exportBrandRider(e,r={}){const s={...this.DEFAULT_OPTIONS,...r},i=this.generateBrandRiderHTML(e);return this.generatePDF(i,{...s,filename:s.filename||`${e.title.toLowerCase().replace(/\s+/g,"-")}-brand-rider.pdf`})}static async exportCV(e,r={}){const s={...this.DEFAULT_OPTIONS,...r},i=this.generateCVHTML(e);return this.generatePDF(i,{...s,filename:s.filename||`${e.name.toLowerCase().replace(/\s+/g,"-")}-cv.pdf`})}static async exportHTML(e,r={}){const s={...this.DEFAULT_OPTIONS,...r};return this.generatePDF(e,s)}static async generatePDF(e,r){try{console.log("Loading PDF export tools...");const{jsPDF:s}=await C();console.log("PDF tools loaded successfully");const i=document.createElement("div");i.innerHTML=e,i.style.position="absolute",i.style.left="-9999px",i.style.top="-9999px",i.style.width="210mm",i.style.backgroundColor="white",i.style.fontFamily="Arial, sans-serif",i.style.fontSize="12px",i.style.lineHeight="1.4",i.style.color="#000000",document.body.appendChild(i);try{const a=new s({orientation:r.orientation,unit:"mm",format:r.format}),n=a.internal.pageSize.getWidth(),o=a.internal.pageSize.getHeight(),l=n-r.margins.left-r.margins.right,p=o-r.margins.top-r.margins.bottom;await this.addHTMLToPDF(a,i,{x:r.margins.left,y:r.margins.top,width:l,height:p});const h=a.output("blob"),m=URL.createObjectURL(h);return console.log("PDF generated successfully"),{blob:h,url:m,filename:r.filename}}finally{document.body.removeChild(i)}}catch(s){throw console.error("PDF export error details:",s),new Error(`PDF export failed: ${s instanceof Error?s.message:"Unknown error"}`)}}static async addHTMLToPDF(e,r,s){const i=this.extractTextContent(r);let a=s.y;const n=6,o=s.width;for(const l of i){a+n>s.y+s.height&&(e.addPage(),a=s.y),l.type==="heading"?(e.setFontSize(16),e.setFont(void 0,"bold")):l.type==="subheading"?(e.setFontSize(14),e.setFont(void 0,"bold")):(e.setFontSize(12),e.setFont(void 0,"normal"));const p=e.splitTextToSize(l.text,o);for(const h of p)a+n>s.y+s.height&&(e.addPage(),a=s.y),e.text(h,s.x,a),a+=n;(l.type==="heading"||l.type==="subheading")&&(a+=3)}}static extractTextContent(e){const r=[],s=i=>{var a,n,o,l;if(i.nodeType===Node.TEXT_NODE){const p=(a=i.textContent)==null?void 0:a.trim();p&&r.push({text:p,type:"text"})}else if(i.nodeType===Node.ELEMENT_NODE){const p=i,h=p.tagName.toLowerCase();if(h==="h1"){const m=(n=p.textContent)==null?void 0:n.trim();m&&r.push({text:m,type:"heading"})}else if(h==="h2"||h==="h3"){const m=(o=p.textContent)==null?void 0:o.trim();m&&r.push({text:m,type:"subheading"})}else if(h==="p"||h==="div"){const m=(l=p.textContent)==null?void 0:l.trim();m&&r.push({text:m,type:"text"})}else if(h==="ul"||h==="ol")p.querySelectorAll("li").forEach((k,c)=>{var _;const g=(_=k.textContent)==null?void 0:_.trim();if(g){const U=h==="ul"?"• ":`${c+1}. `;r.push({text:U+g,type:"text"})}});else for(const m of i.childNodes)s(m)}};return s(e),r}static generateBrandRiderHTML(e){const r=e.palette.map(s=>`<span style="display: inline-block; width: 20px; height: 20px; background-color: ${s.hex}; margin-right: 8px; border: 1px solid #ccc;"></span>${s.name} (${s.hex})`).join("<br>");return`
      <div style="max-width: 210mm; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif;">
        <h1 style="font-size: 24px; margin-bottom: 10px; color: #333;">${e.title}</h1>
        <p style="font-size: 16px; font-style: italic; margin-bottom: 20px; color: #666;">${e.tagline}</p>
        
        <h2 style="font-size: 18px; margin-top: 20px; margin-bottom: 10px; color: #333;">Voice & Tone</h2>
        <p style="margin-bottom: 15px;">${e.voiceTone.join(", ")}</p>
        
        <h2 style="font-size: 18px; margin-top: 20px; margin-bottom: 10px; color: #333;">Signature Phrases</h2>
        <ul style="margin-bottom: 15px;">
          ${e.signaturePhrases.map(s=>`<li style="margin-bottom: 5px;">"${s}"</li>`).join("")}
        </ul>
        
        <h2 style="font-size: 18px; margin-top: 20px; margin-bottom: 10px; color: #333;">Strengths</h2>
        <ul style="margin-bottom: 15px;">
          ${e.strengths.map(s=>`<li style="margin-bottom: 5px;">${s}</li>`).join("")}
        </ul>
        
        <h2 style="font-size: 18px; margin-top: 20px; margin-bottom: 10px; color: #333;">Areas for Growth</h2>
        <ul style="margin-bottom: 15px;">
          ${e.weaknesses.map(s=>`<li style="margin-bottom: 5px;">${s}</li>`).join("")}
        </ul>
        
        <h2 style="font-size: 18px; margin-top: 20px; margin-bottom: 10px; color: #333;">Color Palette</h2>
        <div style="margin-bottom: 15px; line-height: 1.8;">
          ${r}
        </div>
        
        <h2 style="font-size: 18px; margin-top: 20px; margin-bottom: 10px; color: #333;">Typography</h2>
        <p style="margin-bottom: 5px;"><strong>Heading Font:</strong> ${e.fonts.heading}</p>
        <p style="margin-bottom: 15px;"><strong>Body Font:</strong> ${e.fonts.body}</p>
        
        <h2 style="font-size: 18px; margin-top: 20px; margin-bottom: 10px; color: #333;">Bio</h2>
        <p style="margin-bottom: 15px; line-height: 1.6;">${e.bio}</p>
        
        ${e.examples&&e.examples.length>0?`
          <h2 style="font-size: 18px; margin-top: 20px; margin-bottom: 10px; color: #333;">Usage Examples</h2>
          ${e.examples.map(s=>`
            <div style="margin-bottom: 15px; padding: 10px; background-color: #f5f5f5; border-left: 3px solid #333;">
              <h3 style="font-size: 14px; margin-bottom: 5px;">${s.context}</h3>
              <p style="font-style: italic;">"${s.example}"</p>
            </div>
          `).join("")}
        `:""}
      </div>
    `}static generateCVHTML(e){const r=e.experience.map(i=>`
        <div style="margin-bottom: 15px;">
          <h3 style="font-size: 14px; margin-bottom: 5px; color: #333;">${i.role} at ${i.org}</h3>
          <p style="font-size: 12px; color: #666; margin-bottom: 8px;">${i.dates}</p>
          <ul style="margin-left: 20px;">
            ${i.bullets.map(a=>`<li style="margin-bottom: 3px; font-size: 12px;">${a}</li>`).join("")}
          </ul>
        </div>
      `).join(""),s=e.links.map(i=>`<span style="margin-right: 15px;">${i.label}: ${i.url}</span>`).join("");return`
      <div style="max-width: 210mm; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif;">
        <h1 style="font-size: 24px; margin-bottom: 5px; color: #333;">${e.name}</h1>
        <h2 style="font-size: 16px; margin-bottom: 15px; color: #666; font-weight: normal;">${e.role}</h2>
        
        <h3 style="font-size: 18px; margin-top: 20px; margin-bottom: 10px; color: #333;">Summary</h3>
        <p style="margin-bottom: 20px; line-height: 1.6;">${e.summary}</p>
        
        <h3 style="font-size: 18px; margin-top: 20px; margin-bottom: 15px; color: #333;">Experience</h3>
        ${r}
        
        <h3 style="font-size: 18px; margin-top: 20px; margin-bottom: 10px; color: #333;">Skills</h3>
        <p style="margin-bottom: 20px;">${e.skills.join(", ")}</p>
        
        ${e.links&&e.links.length>0?`
          <h3 style="font-size: 18px; margin-top: 20px; margin-bottom: 10px; color: #333;">Links</h3>
          <div style="font-size: 12px; line-height: 1.8;">
            ${s}
          </div>
        `:""}
      </div>
    `}}N(L,"DEFAULT_OPTIONS",{format:"a4",orientation:"portrait",margins:{top:20,right:20,bottom:20,left:20},quality:1,filename:"document.pdf"});class P{static async exportBrandRiderHero(e,r={}){const s={...this.DEFAULT_OPTIONS,...r},i=this.generateBrandRiderHeroHTML(e);return this.generatePNG(i,{...s,filename:s.filename||`${e.title.toLowerCase().replace(/\s+/g,"-")}-hero.png`})}static async exportCVHero(e,r={}){const s={...this.DEFAULT_OPTIONS,...r},i=this.generateCVHeroHTML(e);return this.generatePNG(i,{...s,filename:s.filename||`${e.name.toLowerCase().replace(/\s+/g,"-")}-hero.png`})}static async exportElement(e,r={}){const s={...this.DEFAULT_OPTIONS,...r};try{const{html2canvas:i}=await C(),a=await i(e,{width:s.width,height:s.height,scale:s.scale,backgroundColor:s.backgroundColor,useCORS:!0,allowTaint:!1,logging:!1});return this.canvasToResult(a,s)}catch(i){throw new Error(`PNG export failed: ${i instanceof Error?i.message:"Unknown error"}`)}}static async exportHTML(e,r={}){const s={...this.DEFAULT_OPTIONS,...r};return this.generatePNG(e,s)}static async generatePNG(e,r){try{const{html2canvas:s}=await C(),i=document.createElement("div");i.innerHTML=e,i.style.position="absolute",i.style.left="-9999px",i.style.top="-9999px",i.style.width=`${r.width}px`,i.style.height=`${r.height}px`,i.style.backgroundColor=r.backgroundColor,i.style.overflow="hidden",document.body.appendChild(i);try{const a=await s(i,{width:r.width,height:r.height,scale:r.scale,backgroundColor:r.backgroundColor,useCORS:!0,allowTaint:!1,logging:!1});return this.canvasToResult(a,r)}finally{document.body.removeChild(i)}}catch(s){throw new Error(`PNG export failed: ${s instanceof Error?s.message:"Unknown error"}`)}}static canvasToResult(e,r){return new Promise((s,i)=>{const a=this.getMimeType(r.format);e.toBlob(n=>{if(!n){i(new Error("Failed to generate image blob"));return}const o=URL.createObjectURL(n);s({blob:n,url:o,filename:r.filename,width:e.width,height:e.height})},a,r.quality)})}static getMimeType(e){switch(e){case"jpeg":return"image/jpeg";case"webp":return"image/webp";case"png":default:return"image/png"}}static generateBrandRiderHeroHTML(e){var i,a;const r=((i=e.palette[0])==null?void 0:i.hex)||"#333333",s=((a=e.palette[1])==null?void 0:a.hex)||"#666666";return`
      <div style="
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        background: linear-gradient(135deg, ${r}20, ${s}20);
        font-family: '${e.fonts.heading}', Arial, sans-serif;
        text-align: center;
        padding: 60px 40px;
        box-sizing: border-box;
      ">
        <h1 style="
          font-size: 48px;
          font-weight: bold;
          color: ${r};
          margin: 0 0 20px 0;
          line-height: 1.2;
          text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        ">${e.title}</h1>
        
        <p style="
          font-size: 24px;
          color: ${s};
          margin: 0 0 30px 0;
          font-style: italic;
          font-family: '${e.fonts.body}', Arial, sans-serif;
        ">${e.tagline}</p>
        
        <div style="
          display: flex;
          gap: 15px;
          margin-bottom: 30px;
          flex-wrap: wrap;
          justify-content: center;
        ">
          ${e.palette.slice(0,5).map(n=>`
            <div style="
              width: 40px;
              height: 40px;
              background-color: ${n.hex};
              border-radius: 50%;
              border: 3px solid white;
              box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            "></div>
          `).join("")}
        </div>
        
        <div style="
          background: rgba(255,255,255,0.9);
          padding: 20px 30px;
          border-radius: 12px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.1);
          max-width: 80%;
        ">
          <p style="
            font-size: 18px;
            color: #333;
            margin: 0;
            line-height: 1.4;
            font-family: '${e.fonts.body}', Arial, sans-serif;
          ">${e.voiceTone.slice(0,3).join(" • ")}</p>
        </div>
      </div>
    `}static generateCVHeroHTML(e){return`
      <div style="
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        background: linear-gradient(135deg, #f8fafc, #e2e8f0);
        font-family: 'Inter', Arial, sans-serif;
        text-align: center;
        padding: 60px 40px;
        box-sizing: border-box;
      ">
        <div style="
          background: white;
          padding: 40px;
          border-radius: 16px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.1);
          max-width: 90%;
          width: 100%;
        ">
          <h1 style="
            font-size: 42px;
            font-weight: bold;
            color: #1e293b;
            margin: 0 0 10px 0;
            line-height: 1.2;
          ">${e.name}</h1>
          
          <h2 style="
            font-size: 24px;
            color: #64748b;
            margin: 0 0 25px 0;
            font-weight: normal;
          ">${e.role}</h2>
          
          <p style="
            font-size: 16px;
            color: #475569;
            margin: 0 0 25px 0;
            line-height: 1.6;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
          ">${e.summary}</p>
          
          <div style="
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 20px;
          ">
            ${e.skills.slice(0,6).map(r=>`
              <span style="
                background: #e2e8f0;
                color: #475569;
                padding: 8px 16px;
                border-radius: 20px;
                font-size: 14px;
                font-weight: 500;
              ">${r}</span>
            `).join("")}
          </div>
        </div>
      </div>
    `}static async createSocialMediaImage(e,r="twitter",s={}){const i=this.getSocialMediaDimensions(r),a={...this.DEFAULT_OPTIONS,...i,...s,filename:s.filename||`${e.title.toLowerCase().replace(/\s+/g,"-")}-${r}.png`},n=this.generateSocialMediaHTML(e,r);return this.generatePNG(n,a)}static getSocialMediaDimensions(e){switch(e){case"twitter":return{width:1200,height:675};case"linkedin":return{width:1200,height:627};case"instagram":return{width:1080,height:1080};case"facebook":return{width:1200,height:630};default:return{width:1200,height:630}}}static generateSocialMediaHTML(e,r){const s=e.colors[0]||"#333333",i=e.colors[1]||"#666666";return`
      <div style="
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        background: linear-gradient(135deg, ${s}15, ${i}15);
        font-family: 'Inter', Arial, sans-serif;
        text-align: center;
        padding: 40px;
        box-sizing: border-box;
        position: relative;
      ">
        <div style="
          background: rgba(255,255,255,0.95);
          padding: 40px;
          border-radius: 16px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.1);
          max-width: 80%;
          backdrop-filter: blur(10px);
        ">
          <h1 style="
            font-size: ${r==="instagram"?"36px":"42px"};
            font-weight: bold;
            color: ${s};
            margin: 0 0 ${e.subtitle?"15px":"0"} 0;
            line-height: 1.2;
          ">${e.title}</h1>
          
          ${e.subtitle?`
            <p style="
              font-size: ${r==="instagram"?"18px":"20px"};
              color: ${i};
              margin: 0;
              line-height: 1.4;
            ">${e.subtitle}</p>
          `:""}
        </div>
        
        <div style="
          position: absolute;
          bottom: 20px;
          right: 20px;
          display: flex;
          gap: 8px;
        ">
          ${e.colors.slice(0,4).map(a=>`
            <div style="
              width: 20px;
              height: 20px;
              background-color: ${a};
              border-radius: 50%;
              border: 2px solid white;
              box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            "></div>
          `).join("")}
        </div>
      </div>
    `}}N(P,"DEFAULT_OPTIONS",{width:1200,height:630,quality:.95,backgroundColor:"#ffffff",scale:2,filename:"image.png",format:"png"});function le(){const{token:d}=M(),[e,r]=b.useState(null),[s,i]=b.useState(!0),[a,n]=b.useState(null),[o,l]=b.useState(!1);b.useEffect(()=>{if(!d){n("Invalid share link"),i(!1);return}p()},[d]);const p=async()=>{try{i(!0),n(null);const c=await E.getSharedContent(d);if(!c){n("Content not found or link has expired");return}if(!E.isShareValid(c)){n("This share link has expired");return}r(c)}catch(c){console.error("Error loading shared content:",c),n("Failed to load shared content")}finally{i(!1)}},h=async()=>{if(e)try{l(!0);let c;e.kind==="brand"?c=await L.exportBrandRider(e.content):c=await L.exportCV(e.content);const g=document.createElement("a");g.href=c.url,g.download=c.filename,document.body.appendChild(g),g.click(),document.body.removeChild(g),URL.revokeObjectURL(c.url),w.success("PDF exported successfully")}catch(c){console.error("Export error:",c),w.error("Failed to export PDF")}finally{l(!1)}},m=async()=>{if(e)try{l(!0);let c;e.kind==="brand"?c=await P.exportBrandRiderHero(e.content):c=await P.exportCVHero(e.content);const g=document.createElement("a");g.href=c.url,g.download=c.filename,document.body.appendChild(g),g.click(),document.body.removeChild(g),URL.revokeObjectURL(c.url),w.success("Image exported successfully")}catch(c){console.error("Export error:",c),w.error("Failed to export image")}finally{l(!1)}},k=async()=>{try{await navigator.clipboard.writeText(window.location.href),w.success("Link copied to clipboard")}catch{w.error("Failed to copy link")}};return s?t.jsx("div",{className:"min-h-screen flex items-center justify-center",children:t.jsxs("div",{className:"text-center space-y-4",children:[t.jsx(T,{className:"h-8 w-8 animate-spin mx-auto"}),t.jsx("p",{className:"text-muted-foreground",children:"Loading shared content..."})]})}):a?t.jsx("div",{className:"min-h-screen flex items-center justify-center p-6",children:t.jsx(x,{className:"max-w-md w-full",children:t.jsx(u,{className:"pt-6",children:t.jsxs("div",{className:"text-center space-y-4",children:[t.jsx(B,{className:"h-12 w-12 text-destructive mx-auto"}),t.jsx("h1",{className:"text-xl font-semibold",children:"Content Not Available"}),t.jsx("p",{className:"text-muted-foreground",children:a}),t.jsx(v,{onClick:()=>window.location.href="/",variant:"outline",children:"Go to Homepage"})]})})})}):e?t.jsxs("div",{className:"min-h-screen bg-background",children:[t.jsx("div",{className:"sticky top-0 z-10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b",children:t.jsx("div",{className:"max-w-4xl mx-auto px-6 py-4",children:t.jsxs("div",{className:"flex items-center justify-between",children:[t.jsxs("div",{className:"flex items-center gap-2",children:[t.jsx(V,{className:"h-5 w-5"}),t.jsxs("span",{className:"font-medium",children:["Shared ",e.kind==="brand"?"Brand Rider":"CV"]})]}),t.jsxs("div",{className:"flex items-center gap-2",children:[t.jsx(v,{variant:"outline",size:"sm",onClick:k,children:"Copy Link"}),t.jsx(v,{variant:"outline",size:"sm",onClick:m,disabled:o,children:o?t.jsx(T,{className:"h-4 w-4 animate-spin"}):"Export PNG"}),t.jsx(v,{variant:"outline",size:"sm",onClick:h,disabled:o,children:o?t.jsx(T,{className:"h-4 w-4 animate-spin"}):"Export PDF"})]})]})})}),e.kind==="brand"?t.jsx(I,{sharedContent:e}):t.jsx(q,{sharedContent:e})]}):null}export{le as SharedContent};
